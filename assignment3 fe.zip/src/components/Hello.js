import React from "react";

function Hello() {
    return <h1>Hello</h1>
    }

//const Hello = () => <h1>Hello</h1>

export default Hello;