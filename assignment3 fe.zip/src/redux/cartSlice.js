// src/redux/cartSlice.js
import { createSlice } from '@reduxjs/toolkit';

const cartSlice = createSlice({
  name: 'cart',
  initialState: {
    products: [],
  },
  reducers: {
    addToCart(state, action) {
      const itemInCart = state.products.find(item => item.id === action.payload.id);
      if (!itemInCart) {
        state.products.push({ ...action.payload, quantity: 1 });
      } else {
        itemInCart.quantity++;
      }
    },
    removeFromCart(state, action) {
      return {
        ...state,
        products: state.products.filter(item => item.id !== action.payload),
      };
    },
  },
});

export const { addToCart, removeFromCart } = cartSlice.actions;
export default cartSlice.reducer;